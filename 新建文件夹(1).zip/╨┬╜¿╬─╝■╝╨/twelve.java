package threeone;

public class twelve {
    public static void main(String[] args) {
        int sun=0;
        for(int x=1;x<=5;x++) {
            sun += x;
        }
            System.out.println("结果为"+sun);
    }
}
