package threeone;

public class rhirteen {
    public static void main(String[] args) {
        /*int sun = 0;
        for (int x = 2; x <= 100; x++) {
            if(x%2==0){
                sun+=x;
            }
            x+=1;
        }
        System.out.println("和为"+sun);*/

        int sun = 0;
        for(int x=0;x<=100;x++){

        }
    }
}