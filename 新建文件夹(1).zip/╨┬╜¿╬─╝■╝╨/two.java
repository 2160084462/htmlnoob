package threeone;

public class two {
    public static void main(String[] args) {
        System.out.println("开始");

        int a = 10;
        int b = 20;

        if (a > b) {
            System.out.println("a的值大于b");
        }
        else
            System.out.println("a的值不大于b");

        System.out.println("结束");
    }
}
