package threeone;

public class one {
    public static void main(String[] args){
        System.out.println("开始");
        int a=10;
        int b=20;
        if(a==b){
            System.out.println("a等于b");
        }

        int c=10;
        if(a==c){
            System.out.println("a等于c");
        }
        System.out.println("结束");
    }
}
