package threeone;

public class ten {
    public static void main(String[] args) {
        int x = 8844430;
        double y = 0.1;
        int number=0;
        while(y<=x){
            y*=2;
            number = number+1;
        }
        System.out.println("共折"+number);
    }
}
